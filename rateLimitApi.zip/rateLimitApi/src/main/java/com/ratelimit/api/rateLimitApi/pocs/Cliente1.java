package com.ratelimit.api.rateLimitApi.pocs;

public class Cliente1 {
	
	private String dateTimeInicio;
	private int capacidadeTotal;
	private int consumo;
	private String key;
	
	public int getCapacidadeTotal() {
		return capacidadeTotal;
	}
	public void setCapacidadeTotal(int capacidadeTotal) {
		this.capacidadeTotal = capacidadeTotal;
	}
	public int getConsumo() {
		return consumo;
	}
	public void setConsumo(int consumo) {
		this.consumo = consumo;
	}
	public String getDateTimeInicio() {
		return dateTimeInicio;
	}
	
	public void setDateTimeInicio(String dateTimeInicio) {
		this.dateTimeInicio = dateTimeInicio;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	
	
}
