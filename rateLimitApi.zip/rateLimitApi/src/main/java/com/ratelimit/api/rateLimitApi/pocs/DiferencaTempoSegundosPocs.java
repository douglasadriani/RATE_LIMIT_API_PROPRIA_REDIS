package com.ratelimit.api.rateLimitApi.pocs;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DiferencaTempoSegundosPocs {

//calcular a diferença entre os segundos
	public static void main(String[] args) {
     
		LocalDateTime horaAnteriorFormatado = LocalDateTime.parse("15/01/2022 15:46:38", DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
		System.out.println("Horario Inicio: " + horaAnteriorFormatado);

		String horarioAtual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));       
        LocalDateTime horarioAtualFormatado = LocalDateTime.parse(horarioAtual, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println("Horario Ataul: " + horarioAtualFormatado);
        
        //long segundos = horaAnteriorFormatado.until(horarioAtualFormatado, ChronoUnit.SECONDS);
        
        long segundos = ChronoUnit.SECONDS.between(horaAnteriorFormatado, horarioAtualFormatado);
        
        System.out.println("Diferença em Segundos: " + segundos);
        
        
    }
	
	
	
}
