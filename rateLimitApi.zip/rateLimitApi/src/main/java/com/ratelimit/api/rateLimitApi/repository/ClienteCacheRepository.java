package com.ratelimit.api.rateLimitApi.repository;

import java.util.List;

public interface ClienteCacheRepository {

    Cliente save(Cliente product);

    List<Cliente> findAll();

    void deleteById(String id);

	Cliente findByKey(String key);
}
