package com.ratelimit.api.rateLimitApi.pocs;

import java.util.HashSet;
import java.util.Set;

import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;

public class ConexaoRedisPOC {



		public static void main(String[] args) {
			Jedis jedis = new Jedis("127.0.0.1");
			jedis.set("foo1", "bar");
			String value = jedis.get("foo1");
			//Set<HostAndPort> jedisClusterNodes = new HashSet<HostAndPort>();
			
			//O jedis cluster irá descobrir os outros nós automaticamente.
			//jedisClusterNodes.add(new HostAndPort("127.0.0.1", 6379));
			//JedisCluster jc = new JedisCluster(jedisClusterNodes);
//			/jc.set("foo", "bar");
			//String value = jc.get("foo");


		}

}
