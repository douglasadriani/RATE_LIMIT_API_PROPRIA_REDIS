package com.ratelimit.api.rateLimitApi.service;

import java.util.List;

import com.ratelimit.api.rateLimitApi.repository.Cliente;

public interface ClienteService {

    Cliente save(Cliente cliente);

    List<Cliente> findAll();

    void delete(String key);
    
    Cliente findByKey(String key);
}
