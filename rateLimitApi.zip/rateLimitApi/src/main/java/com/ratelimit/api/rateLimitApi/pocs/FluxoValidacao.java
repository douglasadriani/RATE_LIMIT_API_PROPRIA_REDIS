package com.ratelimit.api.rateLimitApi.pocs;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class FluxoValidacao {
	
	private static final int NUM_ITENS_CONSUMIDOS = 1;
	public static Map<String, Cliente1> bucket = new ConcurrentHashMap<>();
	
	public static String NUM_CONTA ="123";
	public static int CAPACIDADE =5;
	public static long TEMPO =60;
	
	public static void main(String[] args) {
		
		for (int i = 0; i < 100; i++) {
			metodoPrincipal();
			
		}		
		
	}

	private static void metodoPrincipal() {
		
		Cliente1 cliente = obtemCliente(NUM_CONTA);
		
		if( verificaDentroLimiteTempo(cliente) ) {
			
			if(verificaCapacidadeConsumoDisponivel(cliente)) {
				
				//Neste caso esta dentro do tempo e tem capacidade de consumo, somente atualiza o bucket com o novo dado de consumo
				consomeItemBucket(cliente);
			
			}else {
				
				//neste caso não tem capacidade de consumo
				System.out.println("ERRO 429");
				
			}
			
		}else {
			
			//Neste caso ja passou mais do que o tempo configurado, então inserimos o cliente no bucket com as novas caracteristicas
			Cliente1 createCliente = createCliente(NUM_CONTA);
			bucket.put(createCliente.getKey(), createCliente);
		}
	}

	private static void consomeItemBucket(Cliente1 cliente) {
		
		cliente.setConsumo(cliente.getConsumo()+1);
		bucket.put(cliente.getKey(), cliente);
		
	}

	private static boolean verificaCapacidadeConsumoDisponivel(Cliente1 cliente) {
		
		return cliente.getConsumo() < cliente.getCapacidadeTotal();
	}

	private static boolean verificaDentroLimiteTempo(Cliente1 cliente) {
	
		LocalDateTime horaAnteriorFormatado = LocalDateTime.parse(cliente.getDateTimeInicio(), DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
		System.out.println("Horario Inicio: " + horaAnteriorFormatado);

		String horarioAtual = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));       
        LocalDateTime horarioAtualFormatado = LocalDateTime.parse(horarioAtual, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println("Horario Ataul: " + horarioAtualFormatado);
        
        long segundos = ChronoUnit.SECONDS.between(horaAnteriorFormatado, horarioAtualFormatado);
        
        System.out.println("Diferença em Segundos: " + segundos);
    
		return (segundos<=TEMPO);
	}

	private static Cliente1 obtemCliente(String key) {
		
		if(! bucket.containsKey(key)) {
			bucket.put(key, createCliente(key));
		}
		
		return bucket.get(key);
	}

	private static Cliente1 createCliente(String key) {
		
		Cliente1 cliente = new Cliente1();
		cliente.setKey(key);
		cliente.setCapacidadeTotal(CAPACIDADE);
		cliente.setConsumo(NUM_ITENS_CONSUMIDOS);        
        cliente.setDateTimeInicio(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
		
        return cliente;
	}

}
